@echo off
call "%~dp0labkit\START.bat" %*
